require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const Anthropic = require('@anthropic-ai/sdk');

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

/**
 * Generates 3 viral Spanish TikTok titles for a given clip moment.
 * @param {{ start, end, reason, score }} moment
 * @param {number} clipIndex - 0-based index
 * @returns {string[]} array of 3 title strings
 */
async function generateTitles(moment, clipIndex) {
  console.log(`📝 Generating Spanish titles for clip ${clipIndex + 1}...`);

  const duration = Math.round(moment.end - moment.start);

  const response = await client.messages.create({
    model: 'claude-haiku-4-5',
    max_tokens: 512,
    messages: [
      {
        role: 'user',
        content: `Eres un experto en contenido viral de TikTok en español latino. Debes generar títulos que enganchen inmediatamente al espectador.

Contexto del clip:
- Tema/hook: ${moment.reason}
- Duración: ${duration} segundos
- Puntuación viral: ${moment.score}/10

Genera EXACTAMENTE 3 títulos para TikTok en ESPAÑOL. Cada título debe:
✓ Estar en español (no Spanglish)
✓ Tener máximo 100 caracteres
✓ Usar emojis estratégicamente (1–3 por título)
✓ Crear curiosidad, urgencia o impacto emocional inmediato
✓ Tener un hook fuerte desde la primera palabra
✓ Variar el estilo: uno impactante, uno con pregunta, uno con revelación

Responde ÚNICAMENTE con un array JSON de 3 strings. Sin markdown, sin explicaciones:
["título 1", "título 2", "título 3"]`,
      },
    ],
  });

  const raw = response.content[0].text.trim();

  // Extract JSON array
  const jsonMatch = raw.match(/\[[\s\S]*?\]/);
  if (!jsonMatch) {
    console.warn(`  ⚠️  Could not parse titles JSON for clip ${clipIndex + 1}, using fallback`);
    return generateFallbackTitles(moment);
  }

  let titles;
  try {
    titles = JSON.parse(jsonMatch[0]);
  } catch {
    console.warn(`  ⚠️  JSON parse error for clip ${clipIndex + 1}, using fallback`);
    return generateFallbackTitles(moment);
  }

  // Ensure we have exactly 3 strings
  const result = titles
    .filter((t) => typeof t === 'string' && t.trim().length > 0)
    .slice(0, 3);

  while (result.length < 3) {
    result.push(...generateFallbackTitles(moment).slice(result.length));
  }

  console.log(`  ✅ Titles for clip ${clipIndex + 1}:`);
  result.forEach((t, i) => console.log(`     ${i + 1}. ${t}`));

  return result;
}

function generateFallbackTitles(moment) {
  return [
    `😱 No vas a creer lo que pasó...`,
    `🔥 ¿Sabías esto? La verdad que nadie te cuenta`,
    `👀 Esto cambió todo | ${Math.round(moment.score * 10)}% de la gente lo ignora`,
  ];
}

module.exports = { generateTitles };
