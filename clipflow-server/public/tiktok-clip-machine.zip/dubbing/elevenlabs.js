'use strict';

require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });

const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const fetch = require('node-fetch');

const BASE_URL = 'https://api.elevenlabs.io/v1';
const POLL_INTERVAL_MS = 5000;

function apiHeaders(extra = {}) {
  const key = process.env.ELEVENLABS_API_KEY;
  if (!key) throw new Error('ELEVENLABS_API_KEY is not set');
  return { 'xi-api-key': key, ...extra };
}

/**
 * Upload a video/audio file to ElevenLabs dubbing API.
 * Returns the dubbing_id.
 */
async function uploadForDubbing(clipPath) {
  const form = new FormData();
  form.append('file', fs.createReadStream(clipPath), path.basename(clipPath));
  form.append('target_lang', 'es');
  form.append('source_lang', 'en');

  const res = await fetch(`${BASE_URL}/dubbing`, {
    method: 'POST',
    headers: { ...form.getHeaders(), ...apiHeaders() },
    body: form,
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`ElevenLabs upload failed (${res.status}): ${body}`);
  }

  const data = await res.json();
  return data.dubbing_id;
}

/**
 * Poll GET /v1/dubbing/{id} every 5 s until status === 'dubbed'.
 * Throws if status becomes 'failed'.
 */
async function pollUntilDubbed(dubbingId) {
  for (;;) {
    const res = await fetch(`${BASE_URL}/dubbing/${dubbingId}`, {
      headers: apiHeaders(),
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(`ElevenLabs poll failed (${res.status}): ${body}`);
    }

    const data = await res.json();

    if (data.status === 'dubbed') return data;

    if (data.status === 'failed') {
      throw new Error(`ElevenLabs dubbing job failed: ${JSON.stringify(data)}`);
    }

    await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
  }
}

/**
 * Download the dubbed Spanish audio and save it to destPath (mp3).
 */
async function downloadAudio(dubbingId, destPath) {
  const res = await fetch(`${BASE_URL}/dubbing/${dubbingId}/audio/es`, {
    headers: apiHeaders(),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Audio download failed (${res.status}): ${body}`);
  }

  await new Promise((resolve, reject) => {
    const dest = fs.createWriteStream(destPath);
    res.body.pipe(dest);
    dest.on('finish', resolve);
    dest.on('error', reject);
    res.body.on('error', reject);
  });
}

/**
 * Download the Spanish SRT transcript and write it to destPath.
 */
async function downloadTranscript(dubbingId, destPath) {
  const res = await fetch(
    `${BASE_URL}/dubbing/${dubbingId}/transcript/es?format_type=srt`,
    { headers: apiHeaders() }
  );

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Transcript download failed (${res.status}): ${body}`);
  }

  const srt = await res.text();
  fs.writeFileSync(destPath, srt, 'utf-8');
}

module.exports = { uploadForDubbing, pollUntilDubbed, downloadAudio, downloadTranscript };
