'use strict';

const fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');

/**
 * Zero-pad a number to `len` digits.
 */
function pad(n, len = 2) {
  return String(Math.floor(n)).padStart(len, '0');
}

/**
 * Convert milliseconds to SRT timestamp format: HH:MM:SS,mmm
 */
function msToSrtTimestamp(ms) {
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  const s = Math.floor((ms % 60_000) / 1_000);
  const milli = Math.floor(ms % 1_000);
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(milli, 3)}`;
}

/**
 * Write an SRT subtitle file from an array of segments.
 *
 * @param {Array<{start: number, end: number, text: string}>} segments
 *   start/end are in seconds (floats).
 * @param {string} filePath  Absolute path for the output .srt file.
 */
function generateSubtitleFile(segments, filePath) {
  const lines = segments.map((seg, i) => {
    const startMs = Math.round(seg.start * 1000);
    const endMs = Math.round(seg.end * 1000);
    return `${i + 1}\n${msToSrtTimestamp(startMs)} --> ${msToSrtTimestamp(endMs)}\n${seg.text.trim()}`;
  });

  fs.writeFileSync(filePath, lines.join('\n\n') + '\n', 'utf-8');
}

/**
 * Burn SRT subtitles into a video using ffmpeg.
 * Renders white bold text at the bottom centre of the frame.
 *
 * @param {string} videoPath   Input video file.
 * @param {string} srtPath     Input .srt subtitle file.
 * @param {string} outputPath  Output video file.
 * @returns {Promise<void>}
 */
function burnSubtitles(videoPath, srtPath, outputPath) {
  return new Promise((resolve, reject) => {
    // ffmpeg subtitles filter requires forward slashes and escaped colons on all platforms
    const escapedSrt = srtPath.replace(/\\/g, '/').replace(/:/g, '\\:');

    const style = [
      'FontName=Arial',
      'Bold=1',
      'FontSize=18',
      'PrimaryColour=&HFFFFFF&',   // white text
      'OutlineColour=&H000000&',   // black outline
      'Outline=2',
      'Shadow=1',
      'Alignment=2',               // bottom centre (SSA alignment)
      'MarginV=20',
    ].join(',');

    ffmpeg(videoPath)
      .videoFilter(`subtitles='${escapedSrt}':force_style='${style}'`)
      .audioCodec('copy')
      .on('start', (cmd) => console.log('[subtitles] ffmpeg:', cmd))
      .on('end', resolve)
      .on('error', (err) => reject(new Error(`burnSubtitles failed: ${err.message}`)))
      .save(outputPath);
  });
}

module.exports = { generateSubtitleFile, burnSubtitles };
