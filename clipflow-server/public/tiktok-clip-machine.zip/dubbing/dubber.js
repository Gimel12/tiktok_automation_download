'use strict';

require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });

const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const Anthropic = require('@anthropic-ai/sdk');

const { uploadForDubbing, pollUntilDubbed, downloadAudio, downloadTranscript } = require('./elevenlabs');
const { burnSubtitles } = require('./subtitles');

/**
 * Merge a separate audio file into a video, replacing its audio track.
 */
function mergeAudio(videoPath, audioPath, outputPath) {
  return new Promise((resolve, reject) => {
    ffmpeg(videoPath)
      .input(audioPath)
      .outputOptions([
        '-map 0:v:0',    // video from first input
        '-map 1:a:0',    // audio from second input
        '-c:v copy',     // no video re-encode
        '-c:a aac',
        '-shortest',
      ])
      .on('start', (cmd) => console.log('[dubber] merge ffmpeg:', cmd))
      .on('end', resolve)
      .on('error', (err) => reject(new Error(`mergeAudio failed: ${err.message}`)))
      .save(outputPath);
  });
}

/**
 * Use Claude to translate an English SRT to Spanish, preserving SRT format.
 */
async function translateSrtWithClaude(srtContent) {
  const client = new Anthropic();
  const message = await client.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 4096,
    messages: [
      {
        role: 'user',
        content:
          'Translate the following SRT subtitle file from English to Spanish. ' +
          'Preserve all sequence numbers, timestamps, and blank lines exactly. ' +
          'Only translate the dialogue text lines.\n\n' +
          srtContent,
      },
    ],
  });

  return message.content[0].text;
}

/**
 * Dub a video clip into Spanish.
 *
 * Flow:
 *   1. Upload clip to ElevenLabs → poll → download dubbed MP3 + SRT
 *   2. Merge dubbed audio into video
 *   3. Burn SRT subtitles onto video
 *   4. Return { dubbedPath, subtitlePath }
 *
 * Fallback (if ElevenLabs fails):
 *   - Keep original audio
 *   - If an English SRT exists alongside the clip, translate it with Claude
 *   - Burn translated (or empty) subtitles
 *
 * @param {string} clipPath   Absolute path to the source video clip.
 * @param {string} outputDir  Directory where all output files are written.
 * @returns {Promise<{dubbedPath: string, subtitlePath: string}>}
 */
async function dubClip(clipPath, outputDir) {
  fs.mkdirSync(outputDir, { recursive: true });

  const base = path.basename(clipPath, path.extname(clipPath));
  const audioPath  = path.join(outputDir, `${base}_dubbed.mp3`);
  const srtPath    = path.join(outputDir, `${base}.srt`);
  const mergedPath = path.join(outputDir, `${base}_merged.mp4`);
  const finalPath  = path.join(outputDir, `${base}_final.mp4`);

  let usedFallback = false;

  // ── Step 1: ElevenLabs dubbing ──────────────────────────────────────────
  try {
    console.log('[dubber] Uploading clip to ElevenLabs…');
    const dubbingId = await uploadForDubbing(clipPath);

    console.log(`[dubber] Polling job ${dubbingId}…`);
    await pollUntilDubbed(dubbingId);

    console.log('[dubber] Downloading dubbed audio…');
    await downloadAudio(dubbingId, audioPath);

    console.log('[dubber] Downloading SRT transcript…');
    await downloadTranscript(dubbingId, srtPath);
  } catch (err) {
    console.warn(`[dubber] ElevenLabs error: ${err.message}`);
    console.warn('[dubber] Falling back to original audio + Claude translation.');
    usedFallback = true;

    // Try to translate an existing English SRT
    const englishSrt = clipPath.replace(path.extname(clipPath), '.srt');
    if (fs.existsSync(englishSrt)) {
      const englishContent = fs.readFileSync(englishSrt, 'utf-8').trim();
      if (englishContent) {
        try {
          console.log('[dubber] Translating English SRT with Claude…');
          const translated = await translateSrtWithClaude(englishContent);
          fs.writeFileSync(srtPath, translated, 'utf-8');
        } catch (claudeErr) {
          console.warn(`[dubber] Claude translation failed: ${claudeErr.message}`);
          fs.writeFileSync(srtPath, '', 'utf-8');
        }
      } else {
        fs.writeFileSync(srtPath, '', 'utf-8');
      }
    } else {
      console.warn('[dubber] No English SRT found alongside clip. Writing empty SRT.');
      fs.writeFileSync(srtPath, '', 'utf-8');
    }
  }

  // ── Step 2: Merge audio (skip on fallback — keep original audio) ────────
  let videoForSubs = clipPath;

  if (!usedFallback && fs.existsSync(audioPath)) {
    console.log('[dubber] Merging dubbed audio into video…');
    await mergeAudio(clipPath, audioPath, mergedPath);
    videoForSubs = mergedPath;
  }

  // ── Step 3: Burn subtitles ───────────────────────────────────────────────
  const srtContent = fs.existsSync(srtPath)
    ? fs.readFileSync(srtPath, 'utf-8').trim()
    : '';

  if (srtContent) {
    console.log('[dubber] Burning subtitles…');
    await burnSubtitles(videoForSubs, srtPath, finalPath);
  } else {
    console.log('[dubber] No subtitles — copying video as-is.');
    fs.copyFileSync(videoForSubs, finalPath);
  }

  // ── Cleanup intermediate files ───────────────────────────────────────────
  if (fs.existsSync(mergedPath)) {
    fs.unlinkSync(mergedPath);
  }

  console.log(`[dubber] Done → ${finalPath}`);
  return { dubbedPath: finalPath, subtitlePath: srtPath };
}

module.exports = { dubClip };
