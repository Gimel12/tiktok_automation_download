'use strict';

require('dotenv').config();

const express = require('express');
const path = require('path');
const fs = require('fs');
const archiver = require('archiver');
const { v4: uuidv4 } = require('uuid');
const { processVideo } = require('./pipeline/processor');

const app = express();
const PORT = process.env.PORT || 4000;
const OUTPUT_DIR = path.join(__dirname, 'output');
const JOBS_FILE = path.join(__dirname, 'jobs.json');

// ── Persistent job store ───────────────────────────────────────────────
const jobs = new Map();

function saveJobs() {
  try {
    const data = [...jobs.values()].map(j => ({ ...j }));
    fs.writeFileSync(JOBS_FILE, JSON.stringify(data, null, 2));
  } catch (e) { console.error('Failed to save jobs:', e.message); }
}

function loadJobs() {
  if (!fs.existsSync(JOBS_FILE)) return;
  try {
    const data = JSON.parse(fs.readFileSync(JOBS_FILE, 'utf8'));
    for (const job of data) {
      // Mark any interrupted running jobs as error
      if (job.status === 'running' || job.status === 'queued') {
        job.status = 'error';
        job.error = 'Server was restarted while processing';
      }
      jobs.set(job.id, job);
    }
    console.log(`📂 Loaded ${jobs.size} saved job(s) from disk`);
  } catch (e) { console.error('Failed to load jobs:', e.message); }
}

// Load saved jobs on startup
loadJobs();

// ── SSE client registry ────────────────────────────────────────────────
const sseClients = new Set();

function broadcast(data) {
  const payload = `data: ${JSON.stringify(data)}\n\n`;
  for (const client of sseClients) {
    try { client.write(payload); } catch (_) { sseClients.delete(client); }
  }
}

// ── Middleware ─────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── Serve output files (clips) over HTTP ──────────────────────────────
app.use('/output', express.static(OUTPUT_DIR, {
  setHeaders(res, filePath) {
    if (filePath.endsWith('.mp4')) {
      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Accept-Ranges', 'bytes');
    }
  }
}));

// ── POST /api/process ──────────────────────────────────────────────────
app.post('/api/process', (req, res) => {
  const { urls } = req.body;
  if (!Array.isArray(urls) || urls.length === 0) {
    return res.status(400).json({ error: 'urls must be a non-empty array' });
  }

  const jobIds = urls.map(url => {
    const id = uuidv4();
    const job = {
      id,
      url: String(url).trim(),
      status: 'queued',
      createdAt: Date.now(),
      progress: {},
      clips: [],
    };
    jobs.set(id, job);
    saveJobs();
    broadcast({ type: 'job_created', job: safeJob(job) });
    runJob(job);
    return id;
  });

  res.json({ jobIds });
});

// ── GET /api/jobs ──────────────────────────────────────────────────────
app.get('/api/jobs', (_req, res) => {
  res.json([...jobs.values()].map(safeJob));
});

app.get('/api/jobs/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(safeJob(job));
});

// ── DELETE /api/jobs/:id ───────────────────────────────────────────────
app.delete('/api/jobs/:id', (req, res) => {
  if (!jobs.has(req.params.id)) return res.status(404).json({ error: 'Job not found' });
  jobs.delete(req.params.id);
  saveJobs();
  res.json({ ok: true });
});

// ── GET /api/download/:id  — zip all clips ─────────────────────────────
app.get('/api/download/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (job.status !== 'done') return res.status(400).json({ error: 'Job not finished yet' });

  // Find the output dir for this job's video ID
  const clip = job.clips[0];
  if (!clip) return res.status(404).json({ error: 'No clips found' });

  const videoDir = path.dirname(clip.clipPath);
  if (!fs.existsSync(videoDir)) return res.status(404).json({ error: 'Output directory not found' });

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="tiktok_clips_${job.id.slice(0,8)}.zip"`);

  const archive = archiver('zip', { zlib: { level: 6 } });
  archive.on('error', err => { console.error('Archive error', err); res.end(); });
  archive.pipe(res);

  // Add only mp4 files
  const mp4s = fs.readdirSync(videoDir).filter(f => f.endsWith('.mp4') && f.startsWith('clip_'));
  mp4s.forEach(f => archive.file(path.join(videoDir, f), { name: f }));
  archive.finalize();
});

// ── GET /api/progress  (SSE) ───────────────────────────────────────────
app.get('/api/progress', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const snapshot = [...jobs.values()].map(safeJob);
  res.write(`data: ${JSON.stringify({ type: 'snapshot', jobs: snapshot })}\n\n`);

  sseClients.add(res);
  const keepalive = setInterval(() => {
    try { res.write(': ping\n\n'); } catch (_) { clearInterval(keepalive); }
  }, 15000);

  req.on('close', () => {
    clearInterval(keepalive);
    sseClients.delete(res);
  });
});

// ── SPA fallback ───────────────────────────────────────────────────────
app.get('/{*splat}', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Job runner ─────────────────────────────────────────────────────────
async function runJob(job) {
  job.status = 'running';
  job.startedAt = Date.now();
  broadcast({ type: 'job_started', jobId: job.id });

  try {
    const result = await processVideo(job.url, job.id, (progress) => {
      job.progress = progress;
      broadcast({ type: 'job_progress', jobId: job.id, progress });
    });

    // Attach HTTP-accessible URLs to each clip
    job.clips = result.clips.map(clip => {
      const rel = path.relative(OUTPUT_DIR, clip.clipPath).replace(/\\/g, '/');
      return {
        ...clip,
        url: `/output/${rel}`,
        filename: path.basename(clip.clipPath),
        dubbedUrl: clip.dubbedPath ? `/output/${path.relative(OUTPUT_DIR, clip.dubbedPath).replace(/\\/g, '/')}` : null,
        dubbedFilename: clip.dubbedPath ? path.basename(clip.dubbedPath) : null,
      };
    });

    job.status = 'done';
    job.finishedAt = Date.now();
    saveJobs();
    broadcast({ type: 'job_done', job: safeJob(job) });
  } catch (err) {
    job.status = 'error';
    job.error = err.message;
    job.finishedAt = Date.now();
    saveJobs();
    broadcast({ type: 'job_error', jobId: job.id, error: err.message });
    console.error(`Job ${job.id} failed:`, err);
  }
}

// ── Helpers ────────────────────────────────────────────────────────────
function safeJob(job) {
  const { id, url, status, createdAt, startedAt, finishedAt, progress, clips, error } = job;
  return { id, url, status, createdAt, startedAt, finishedAt, progress, clips, error };
}

// ── Start ──────────────────────────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log(`TikTok Clip Machine running → http://192.168.12.207:${PORT}`);
});
